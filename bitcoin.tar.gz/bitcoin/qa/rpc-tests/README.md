Regression tests of RPC interface
=================================

wallet.sh : Test wallet send/receive code (see comments for details)

util.sh : useful re-usable functions 
