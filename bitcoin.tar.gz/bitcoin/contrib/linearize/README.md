### Linearize ###
Construct a linear, no-fork, best version of the blockchain.