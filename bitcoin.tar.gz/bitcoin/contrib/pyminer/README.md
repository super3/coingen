### PyMiner ###

This is a 'getwork' CPU mining client for Bitcoin. It is pure-python, and therefore very, very slow.  The purpose is to provide a reference implementation of a miner, for study.

### Other Resources ###

- [BitcoinTalk Thread](https://bitcointalk.org/index.php?topic=3546.0)
- [Jgarzik Repo](https://github.com/jgarzik/pyminer)